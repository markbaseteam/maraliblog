---
category: Guide
date: 01-01-2015
publish: true
title: RP —  Guide Fiche
type: Aide
toc: true
update: false
tag:
- Écriture
- RP/Aide/Fiche
---

→ [[RP —  Guide création de personnage]] 

# Description mentale
## Généralité
- Sociabilité
- Impulsivité
- Défauts
- Qualités

## Spécificité
- Famille & Relations 
- Peurs
- Traits de caractères autres
- Loisir

## Ambition
- But dans la vie
- Vision de l'avenir
- Façon de pensée - politique

## Capacité
- Langue
- Accents
- Talents

----
# Physique
## Générale
- Cheveux
- Démarche
- Voix
- Expression faciale

## Visage
- Forme
- Yeux : Forme, couleurs & taille
- Nez : Forme, taille
- Bouche : forme, taille, couleur
- Pilosité faciale
- Cicatrice
- Tatouage
- Bouton ; tâche…
- Accessoires

## Carrure
- Musculature
- Taille
- Poids
- Cicatrice
- Tatouages

## Vêtements
- Style vestimentaire
- Vêtements habituels
- Uniforme ?
- Accessoires
- Armes

----
# Histoire
1. Parents
2. Enfance
3. Adolescence
4. Adulte
5. Présent

----