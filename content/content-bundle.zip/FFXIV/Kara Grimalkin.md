---
folder: Roleplay
date: 17-07-2021
title: Kara Grimalkin
type: Personnage, OC
genre: PJ
category: FFXIV
image: Kara
---
[[20. Compendium/22. Personnages/Kara Grimalkin/Kara Grimalkin|Kara Grimalkin]]

Kara est née en [[Lieu#Gardemald|Gardemald]], dans une des régions annexée par l'empire.

Elle possède l' #Écho, mais aussi l'étrange capacité de voir l'Ether et l'âme des gens sous forme de couleur. ([[Ancien]])

Cette capacité l'a amené à être sujet d'expérience pour l'empire. Par chance, au bord de la mort, elle réussi à s'échapper.
Suite à cela, elle devient une simple mercenaire et aventurière, essayant de cacher ces capacités malgré son pacte ( #Faucheur) avec un être "issu" du #Néant sans réellement en être.

Kara est une personne extrêmement seule et solitaire. Elle a peur des autres et de leur faire confiance. En outre, sa puissance la rend difficile à approcher. 