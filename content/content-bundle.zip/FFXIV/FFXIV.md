---
publish: false
type: Index
univers: FFXIV
name: Index
obsidian_ui_mode: preview
description: Index
tag:
- FFXIV/Index
---
 
```dataview
LIST FROM "30. Scriptorium/FFXIV"
WHERE univers = "FFXIV" AND type != "Index"
```

