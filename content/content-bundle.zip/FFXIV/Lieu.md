---
publish: false
type: [Lieu, note]
univers: FFXIV
name: Lieu
description: Description de divers lieu dans FFXIV
tag:
- FFXIV/Lieu
---

# Gardemald 
#FFXIV/Lieu/Gardemald