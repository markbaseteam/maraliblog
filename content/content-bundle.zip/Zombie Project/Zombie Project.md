---
type: Informations, Idées
univers: Resident Evil
obsidianUIMode: preview
share: true
date: 26-10-2021
description: Info sur le mini rp Resident Evil
category: Roleplay/Idées/Zombie Project
---

[Serveur](https://discord.gg/qGKFutdY4R)

<u>Lieu</u> : Windport — Côte West des USA
<u>Météo</u> : Un typhon est en cours 
<u>Timeline</u> : Une semaine après la dispersion initiale du virus.
<u>Cause</u> : Inconnue

---
L'univers est basé sur Resident Evil 2 et 3. Il se déroule autour de la timeline du 2.

Pour info :
- Resident Evil 3 (partie 1) : 26 → 28 Septembre
- Resident Evil 2 : 28 Septembre → 30 septembre
- Resident Evil 3 (2e partie) : 1er Octobre

Cependant, ici Racoon city n'existe pas. Le premier évènement à lieu à Windport. Il existe cependant d'autre laboratoire dans d'autres villes du globe.

Il est tout à fait possible d'introduire des éléments de différents univers, tant que cela reste cohérent avec le contexte.

Il est possible de faire des personnages mutants.

---
![[Introduction Zombie Project|Introduction]]