---
type: Idées
univers: Resident Evil
date: 26-10-2021
obsidianUIMode: preview
share: true
category: Roleplay/Idées/Zombie Project
---

[Serveur](https://discord.gg/qGKFutdY4R)

---
*La tempête faisait rage, le vent s'était levée deux heures plus tôt et de haute et lourde vague frappait les digues de la petite ville portuaire. 
La nuit noire était tombée depuis longtemps, plongeant la ville dans un silence apocalyptique.*

*Quelque lumière, ici et là, vacillaient dans le vent.*

*Les voitures avaient été abandonnées, et leurs feux éteints depuis longtemps.*

*Les mâts des bateaux se frappaient entre eux, ignorant l'apocalypse.* 

*Certains avaient tenté de fuir, durant le cataclysme. Combien était morts, par la tempête et l'infection ? Combien de cadavre seront rejeté par la mer, sur les côtes, dans les jours, semaines et mois à venir ?*

*Windport n'était plus qu'une ville fantôme, habitée par le silence et les râles d'agonies.*

---

*La douleur était insoutenable. Son bras n'était plus qu'un moignon, réduits en charpie par un éboulement alors qu'elle tentait de fuir le chaos du laboratoire.*

*Elle était tombée, de nombreuses fois. Elle avait glissé dans la boue, les cadavres et l'eau charriée par les égouts.*

*Elle avait faim.
Elle avait soif.
Elle était triste et en colère.*

*Vêtue simplement d'une blouse, elle n'avait même pas eu le temps de se changer après leurs... Expériences. 
Elle était pied nu.*

*Elle se hissa sur un trottoir, hors de la boue. 
Le sang noir perlait de ses blessures, épais et visqueux. Il coagulait déjà.*

*Elle avait sommeil.*

*Éden se recroquevilla dans un coin, ramenant ses jambes contre son torse. 
Elle avait si sommeil...*