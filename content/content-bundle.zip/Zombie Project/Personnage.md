---
type: idées
univers: Resident Evil
share: false
---

# Mutants
- Eden : [[Biomasse]], [[Super physique]]
- Isaac : [[Télépathie]] ; [[Suggestion]] ; [[Prédictions]]
- Ambre : [[Biomasse]] ; [[Super physique]]
- Maria : Monstre ; 
- Jayzee : [[Estompage]]