En réalité, le monde a été récréé par "Dieu", après avoir analysé l'histoire humaine. Mais le monde n'a pas été totalement nettoyé de l'histoire précédente, et il reste des *souvenirs* aux humains. 

De plus, la population mondiale a été "unifié" de 7 milliards à 1 milliards. Chaque personne est en réalité la fusion entre septs âmes, les plus semblables à elle, car la légende "Il existe 7 sosies de sois-même" est réelle.
C'est pour cela que certains : 
- Rêve de l'ancien monde (les cauchemars)
- Ils connaissent des concepts n'existant pas dans leur monde (guerre, pauvreté, maladie)
Et qu'il existe des ruines à divers endroits de l'anciens monde et de son urbanisation.


